#!/bin/sh

cd $HOME

tar cf /tmp/mead-creds.tar \
  .artifactory  \
  .credentials.d/.artifactory  \
  .credentials.d/slack-*  \
  .credentials.d/jenkins-* \
  .credentials.d/venafi* \
  .credentials.d/rundeck-ciuser-user \
  .credentials.d/rundeck-svcaecjnk-user \
  .credentials.d/kube-svcak8sci \
  .credentials.d/jira-* \
  .credentials.d/frontend-user \
  .credentials.d/cmx-* \
  .credentials.d/artifactory-devops_ro-user \
  .credentials.d/artifactory-mavenbuild-user \
